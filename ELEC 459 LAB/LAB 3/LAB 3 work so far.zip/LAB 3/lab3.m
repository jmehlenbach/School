clear all;
close all;
clc;

load homework.mat;
load homework_if.mat;

homework_orig = homework;
homework_noisy = homework_if;

figure(1);
subplot(2,1,1);
imshow(homework_orig,[]);
subplot(2,1,2);
imshow(homework_noisy,[]);

% choosing row 200, where only interference information is visible

row_200 = homework_noisy(200,:);
figure(2);
imshow(row_200,[]);

row_200_fft = fft(row_200);

Fs = 1520;
T = 1/Fs;
L = length(row_200);
t = (0:L-1)*T;

P2 = abs(row_200_fft / L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);
f = Fs*(0:(L/2))/L;

figure(3);
plot(f,P1);
 


